class calc:

    def suma(self,x,y):
        print ("el resultado de suma  es "+str((x+y)))
    def resta(self,x,y):
        print ("el resultado de resta   es "+str((x-y)))
    def mult(self,x,y):
        print ("el resultado de multiplicacion   es "+str((x*y)))
    def div(self,x,y):
        print ("el resultado de division  es "+str((x/y)))