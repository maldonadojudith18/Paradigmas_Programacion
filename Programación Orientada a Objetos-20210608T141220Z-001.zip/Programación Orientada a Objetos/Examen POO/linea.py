class Punto():
    def(self,_puntoA,_puntoB):
        self._puntoA = _puntoA
        self._puntoB = _puntoB
class linea():
    def __init__(self,_puntoA,_puntoB):
       self._puntoA = _puntoA.getPunto()
       self._puntoB = _puntoB.getPunto()
    @classmethod
    def linea(cls):
        self._puntoA = [0,0]
        self._puntoB = [0,0]

    @property
    def pA(self):
        return _puntoA
    @pA.setter
    def pA(self,pA):
        self  _puntoB
    def linea (self, _puntoA,_puntoB):
    def muevederecha(double):
    def mueveizquierda(double):
    def muevearriba (double):
    def mueveabajo(double):
